// Made By JohnSwag-Crypto // 
// Basic Program Made // 

#include <iostream>
#include <stdio.h>
#include <string>

using namespace std;

int main(void)


{
	// List of Profits

	int Ultimate_Skins;
	int Mythic_Skins;
	int Legendary_Skins;
	int Epic_Skins;
	int Legacy_Skins;
	int Regular_Skins;
	int Chroma_Skins;
	int Rune_Pages;
	int Emotes;
	int Icons;
	int Wards;



	// List of Multipliers

	int total1, Multiplier_Ultimate_Skins = 25;
	int total2, Multiplier_Mythic_Skins = 45;
	int total3, Multiplier_Legendary_Skins = 20;
	int total4, Multiplier_Epic_Skins = 10;
	int total5, Multiplier_Legacy_Skins = 10;
	int total6, Multiplier_Regular_Skins = 5;
	int total7, Multiplier_Chroma_Skins = 3;
	int total8, Multiplier_Rune_Pages = 2;
	int total9, Multiplier_Emotes = 2;
	int total10, Multiplier_Icons = 1;
	int total11, Multiplier_Wards = 2;

	cout << "\n----------------------------------------------";

	cout << "\n| League Of Legends Account Calculation 2020 |";

	cout << "\n----------------------------------------------";

	cout << "\n";

	cout << "This Will Only Calculate The Price Of Skins/Chromas/Wards/Runes/Icons/Emotes \n";

	cout << "\n";

	// Shit to calculate 
	cout << "How Many Ultimate Skins: ";

	cin >> Ultimate_Skins;

	cout << "How Many Mythic Skins: ";

	cin >> Mythic_Skins;

	cout << "How Many Legendary Skins: ";
	
	cin >> Legendary_Skins;

	cout << "How Many Epic Skins: ";

	cin >> Epic_Skins;

	cout << "How Many Legacy Skins: ";

	cin >> Legacy_Skins;

	cout << "How Many Regular Skins: ";

	cin >> Regular_Skins;

	cout << "How Many Chroma Skins: ";

	cin >> Chroma_Skins;

	cout << "How Many Rune Pages: ";

	cin >> Rune_Pages;

	cout << "How Many Emotes: ";

	cin >> Emotes;

	cout << "How Many Icons: ";

	cin >> Icons;

	cout << "How Many Wards: ";

	cin >> Wards;



	total1 = Ultimate_Skins * Multiplier_Ultimate_Skins;
	total2 = Mythic_Skins * Multiplier_Mythic_Skins;
	total3 = Legendary_Skins * Multiplier_Legendary_Skins;
	total4 = Epic_Skins * Multiplier_Epic_Skins;
	total5 = Legacy_Skins * Multiplier_Legacy_Skins;
	total6 = Regular_Skins * Multiplier_Regular_Skins;
	total7 = Chroma_Skins * Multiplier_Chroma_Skins;
	total8 = Rune_Pages * Multiplier_Rune_Pages;
	total9 = Emotes * Multiplier_Emotes;
	total10 = Icons * Multiplier_Icons;
	total11 = Wards * Multiplier_Icons;


	cout << "\n-----------------------------------------";

	cout << "\n| League Of Legends Account Total Value |";

	cout << "\n-----------------------------------------";

	cout << "\n";

	cout << "\nYour Account is Worth $";

	cout << total1 + total2 + total3 + total4 + total5 + total6 + total7 + total8 + total9 + total10 +total11 << endl;


	system("pause");
	return 0;


}